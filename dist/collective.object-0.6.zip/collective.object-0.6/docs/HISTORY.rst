Changelog
=========

0.6 (2015-04-13)
-------------------

- Refactor object schema.
- Add @@edit custom template.
- Add custom adapter for object creation.

0.5 (2015-04-10)
-------------------

- Add object identification fields. 
- Add NL translation to identification fields.

0.4 (2015-04-09)
-------------------

- Add main fields.
- Add dexterity indexer behavior.
- Change view template to get meta tags. 
- Add translations for fields.

0.3 (2015-04-09)
-------------------

- Add collection fieldset

0.2 (2015-04-09)
-------------------

- Transform object in schema driven type. Add DataGridField support

0.1 (2015-04-09)
-------------------

- Initial release
