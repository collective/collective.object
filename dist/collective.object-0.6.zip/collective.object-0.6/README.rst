Introduction
============

Information about an object typically collected by museums
