Introduction
============

Information about a collectible object used by museums
