Changelog
=========

0.3 (2015-04-09)
-------------------

- Add collection fieldset

0.2 (2015-04-09)
-------------------

- Transform object in schema driven type. Add DataGridField support

0.1 (2014-11-14)
-------------------

- Initial release
